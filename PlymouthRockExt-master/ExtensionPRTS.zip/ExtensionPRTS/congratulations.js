document.addEventListener('DOMContentLoaded', () => {
    // Wait for 5 seconds (5000 milliseconds), then redirect to Level 1
    setTimeout(() => {
        window.location.href = 'Level1.html'; // Adjust the file name as needed
    }, 5000);
});